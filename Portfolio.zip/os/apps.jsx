// All app windows for VishalRavi's Portfolio OS
// Each app is a React component rendered inside <OSWindow>'s content area.
// Common TUI aesthetic: monospace, ASCII section dividers, hover highlights.

const D = () => window.PORTFOLIO_DATA;

// ── Shared bits ────────────────────────────────────────────────────────
function TuiDivider({ char = "─", label, color = "var(--border-bright)" }) {
  if (label) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, color, fontSize: 12, margin: '12px 0 8px', letterSpacing: '0.06em' }}>
        <span>┌─</span>
        <span style={{ color: 'var(--accent)', textShadow: 'var(--text-glow)' }}>{label}</span>
        <span style={{ flex: 1, overflow: 'hidden' }}>{char.repeat(200)}</span>
      </div>
    );
  }
  return <div style={{ color, opacity: 0.6, fontSize: 12, letterSpacing: '0.06em', whiteSpace: 'nowrap', overflow: 'hidden' }}>{char.repeat(200)}</div>;
}

function Chip({ children, color }) {
  return (
    <span style={{
      display: 'inline-block',
      padding: '2px 8px',
      border: `1px solid ${color || 'var(--border-bright)'}`,
      color: color || 'var(--fg-dim)',
      fontSize: 11,
      fontFamily: 'var(--font-mono)',
      letterSpacing: '0.04em',
      lineHeight: 1.6,
      borderRadius: 0,
    }}>
      {children}
    </span>
  );
}

function Box({ children, label, color = 'var(--border-bright)', style }) {
  return (
    <div style={{ position: 'relative', border: `1px solid ${color}`, padding: '14px 16px 14px', margin: '8px 0', ...style }}>
      {label && (
        <span style={{
          position: 'absolute', top: -8, left: 12, padding: '0 6px',
          background: 'var(--surface)', color: 'var(--accent)',
          fontSize: 11, letterSpacing: '0.08em', textShadow: 'var(--text-glow)',
        }}>{label}</span>
      )}
      {children}
    </div>
  );
}

const appPad = { padding: 18, fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--fg)', lineHeight: 1.55 };

// ── About ──────────────────────────────────────────────────────────────
function AppAbout() {
  const d = D();
  return (
    <div style={appPad}>
      {/* ASCII banner */}
      <pre style={{ margin: 0, color: 'var(--accent)', textShadow: 'var(--text-glow)', fontSize: 11, lineHeight: 1.1, overflowX: 'auto' }}>
{`  ██╗   ██╗██╗███████╗██╗  ██╗ █████╗ ██╗
  ██║   ██║██║██╔════╝██║  ██║██╔══██╗██║
  ██║   ██║██║███████╗███████║███████║██║
  ╚██╗ ██╔╝██║╚════██║██╔══██║██╔══██║██║
   ╚████╔╝ ██║███████║██║  ██║██║  ██║███████╗
    ╚═══╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝`}
      </pre>

      <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', gap: 18, marginTop: 18, alignItems: 'start' }}>
        {/* Avatar placeholder */}
        <div style={{
          width: 120, height: 120,
          border: '1px solid var(--border-bright)',
          background: 'var(--bg-inset)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--accent)', fontSize: 40, textShadow: 'var(--text-glow)',
          backgroundImage: `repeating-linear-gradient(45deg, var(--surface-alt) 0 6px, transparent 6px 12px)`,
        }}>
          <span style={{ background: 'var(--surface)', padding: '4px 10px', border: '1px solid var(--border-bright)', fontSize: 14 }}>
            VRM
          </span>
        </div>
        <div>
          <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--accent)', textShadow: 'var(--text-glow)', letterSpacing: '0.02em' }}>
            {d.user.name}
          </div>
          <div style={{ color: 'var(--fg-dim)', fontSize: 12, marginTop: 4 }}>
            &gt; {d.user.title}
          </div>
          <div style={{ color: 'var(--fg-mute)', fontSize: 11, marginTop: 4 }}>
            [ {d.user.location} · {d.user.email} ]
          </div>
          <div style={{ marginTop: 10, fontSize: 12, color: 'var(--fg)', borderLeft: '2px solid var(--accent)', paddingLeft: 10 }}>
            {d.user.tagline}
          </div>
        </div>
      </div>

      <TuiDivider label="BIO" />
      <div style={{ whiteSpace: 'pre-wrap', color: 'var(--fg-dim)', fontSize: 13 }}>
        {d.user.bio.join('\n')}
      </div>

      <TuiDivider label="QUICK STATS" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 10 }}>
        {[
          { k: 'PROJECTS', v: '4+', sub: 'shipped' },
          { k: 'PUBLICATIONS', v: '1', sub: 'IJFMR' },
          { k: 'AWARDS', v: '1', sub: 'Best Innovative' },
          { k: 'LANGUAGES', v: '9+', sub: 'fluent' },
        ].map((s) => (
          <Box key={s.k} style={{ margin: 0, padding: '10px 12px' }}>
            <div style={{ color: 'var(--fg-mute)', fontSize: 10, letterSpacing: '0.1em' }}>{s.k}</div>
            <div style={{ color: 'var(--accent)', fontSize: 22, fontWeight: 700, textShadow: 'var(--text-glow)', lineHeight: 1.1 }}>{s.v}</div>
            <div style={{ color: 'var(--fg-dim)', fontSize: 11 }}>{s.sub}</div>
          </Box>
        ))}
      </div>
    </div>
  );
}

// ── Projects (file-browser style) ──────────────────────────────────────
function AppProjects({ initialSelect }) {
  const d = D();
  const [sel, setSel] = React.useState(initialSelect || d.projects[0].id);
  const selected = d.projects.find((p) => p.id === sel) || d.projects[0];

  return (
    <div style={{ height: '100%', display: 'flex', fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--fg)' }}>
      {/* File list */}
      <div style={{
        width: 240,
        borderRight: '1px solid var(--border-bright)',
        background: 'var(--bg-inset)',
        overflow: 'auto',
      }}>
        <div style={{ padding: '10px 12px', fontSize: 11, color: 'var(--fg-mute)', letterSpacing: '0.1em', borderBottom: '1px solid var(--border)' }}>
          ~/projects/
        </div>
        {d.projects.map((p) => (
          <div
            key={p.id}
            onClick={() => setSel(p.id)}
            style={{
              padding: '8px 12px',
              cursor: 'pointer',
              background: sel === p.id ? 'var(--sel-bg)' : 'transparent',
              color: sel === p.id ? 'var(--sel-fg)' : 'var(--fg-dim)',
              borderLeft: sel === p.id ? '2px solid var(--accent)' : '2px solid transparent',
              fontSize: 12,
            }}
            onMouseEnter={(e) => { if (sel !== p.id) e.currentTarget.style.background = 'var(--surface-alt)'; }}
            onMouseLeave={(e) => { if (sel !== p.id) e.currentTarget.style.background = 'transparent'; }}
          >
            <span style={{ color: 'var(--warn)', marginRight: 6 }}>▸</span>
            {p.filename}
          </div>
        ))}
        <div style={{ padding: '14px 12px', fontSize: 10, color: 'var(--fg-mute)' }}>
          {d.projects.length} items · drwxr-xr-x
        </div>
      </div>

      {/* Detail */}
      <div style={{ flex: 1, overflow: 'auto', padding: 18 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--accent)', textShadow: 'var(--text-glow)' }}>
            {selected.name}
          </div>
          <div style={{ fontSize: 10, color: 'var(--fg-mute)', letterSpacing: '0.08em' }}>
            PROJECT · {selected.id.toUpperCase()}
          </div>
        </div>
        <div style={{ color: 'var(--fg-dim)', fontSize: 12, marginTop: 4 }}>
          &gt; {selected.summary}
        </div>
        <div style={{ marginTop: 10, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {selected.tags.map((t) => <Chip key={t}>{t}</Chip>)}
        </div>

        <TuiDivider label="README.md" />
        <ul style={{ paddingLeft: 0, listStyle: 'none', margin: 0 }}>
          {selected.bullets.map((b, i) => (
            <li key={i} style={{ display: 'flex', gap: 10, marginBottom: 10, fontSize: 13, color: 'var(--fg)' }}>
              <span style={{ color: 'var(--accent)', opacity: 0.7, flex: '0 0 auto' }}>▪</span>
              <span style={{ flex: 1 }}>{b}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

// ── Experience (timeline) ──────────────────────────────────────────────
function AppExperience() {
  const d = D();
  return (
    <div style={appPad}>
      <div style={{ fontSize: 11, color: 'var(--fg-mute)', letterSpacing: '0.1em' }}>$ cat ~/experience.log</div>
      <TuiDivider />
      {d.experience.map((e, i) => (
        <div key={i} style={{ display: 'grid', gridTemplateColumns: '24px 1fr', gap: 12, marginBottom: 18 }}>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{ width: 10, height: 10, border: '2px solid var(--accent)', boxShadow: '0 0 10px var(--accent-glow)', background: 'var(--bg)' }} />
            {i < d.experience.length - 1 && <div style={{ width: 1, flex: 1, background: 'var(--border-bright)', marginTop: 4 }} />}
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
              {/* Logo slot — user drops a real logo image here; persists across reloads */}
              <image-slot
                id={e.logoSlotId}
                placeholder={e.logoPlaceholder || 'drop logo'}
                shape="rounded"
                radius="4"
                fit="contain"
                style={{
                  width: 56, height: 56, flex: '0 0 56px',
                  border: '1px solid var(--border-bright)',
                  background: 'var(--bg-inset)',
                }}
              />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 12, flexWrap: 'wrap' }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--accent)', textShadow: 'var(--text-glow)' }}>
                    {e.role} <span style={{ color: 'var(--fg-dim)', fontWeight: 400 }}>@ {e.company}</span>
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--fg-mute)', letterSpacing: '0.06em' }}>
                    {e.period}
                  </div>
                </div>
                <div style={{ color: 'var(--fg-mute)', fontSize: 11, marginTop: 2 }}>[{e.location}]</div>
              </div>
            </div>
            <ul style={{ paddingLeft: 0, listStyle: 'none', margin: '10px 0 0' }}>
              {e.bullets.map((b, j) => (
                <li key={j} style={{ display: 'flex', gap: 8, marginBottom: 6, fontSize: 12 }}>
                  <span style={{ color: 'var(--accent)', opacity: 0.7 }}>▸</span>
                  <span style={{ color: 'var(--fg)' }}>{b}</span>
                </li>
              ))}
            </ul>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
              {e.stack.map((s) => <Chip key={s}>{s}</Chip>)}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Education ──────────────────────────────────────────────────────────
function AppEducation() {
  const d = D();
  return (
    <div style={appPad}>
      <div style={{ fontSize: 11, color: 'var(--fg-mute)', letterSpacing: '0.1em' }}>$ ls -la ~/education/</div>
      <TuiDivider />
      {d.education.map((e, i) => (
        <Box key={i} label={`SCHOOL_${String(i + 1).padStart(2, '0')}`}>
          <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--accent)', textShadow: 'var(--text-glow)' }}>
            {e.school}
          </div>
          <div style={{ color: 'var(--fg-mute)', fontSize: 11, marginTop: 2 }}>{e.location}</div>
          <div style={{ marginTop: 8, display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
            <span style={{ color: 'var(--fg)', fontSize: 13 }}>{e.degree}</span>
            <span style={{ color: 'var(--fg-dim)', fontSize: 12, letterSpacing: '0.06em' }}>{e.period}</span>
          </div>
          <ul style={{ paddingLeft: 0, listStyle: 'none', margin: '10px 0 0' }}>
            {e.highlights.map((h, j) => (
              <li key={j} style={{ fontSize: 12, color: 'var(--fg-dim)' }}>
                <span style={{ color: 'var(--accent)' }}>★</span> {h}
              </li>
            ))}
          </ul>
        </Box>
      ))}
    </div>
  );
}

// ── Skills ─────────────────────────────────────────────────────────────
function AppSkills() {
  const d = D();
  const groups = Object.entries(d.skills);
  return (
    <div style={appPad}>
      <div style={{ fontSize: 11, color: 'var(--fg-mute)', letterSpacing: '0.1em' }}>
        $ cat /etc/skills.conf · {groups.reduce((n, [_, v]) => n + v.length, 0)} entries
      </div>
      <TuiDivider />
      {groups.map(([k, vals]) => (
        <div key={k} style={{ marginBottom: 16 }}>
          <div style={{ color: 'var(--accent)', fontSize: 12, textShadow: 'var(--text-glow)', letterSpacing: '0.08em', marginBottom: 8 }}>
            [{k.toUpperCase()}]
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {vals.map((s) => <Chip key={s}>{s}</Chip>)}
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Achievements ───────────────────────────────────────────────────────
function AppAchievements() {
  const d = D();
  return (
    <div style={appPad}>
      <div style={{ fontSize: 11, color: 'var(--fg-mute)', letterSpacing: '0.1em' }}>$ cat ~/awards.txt</div>
      <TuiDivider />
      {d.achievements.map((a, i) => (
        <Box key={i} style={{ marginBottom: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12, flexWrap: 'wrap' }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--accent)', textShadow: 'var(--text-glow)' }}>
              {a.type === 'Publication' ? '📜' : '🏆'} {a.title}
            </div>
            <Chip color={a.type === 'Publication' ? 'var(--info)' : 'var(--warn)'}>
              {a.type.toUpperCase()} · {a.year}
            </Chip>
          </div>
          <div style={{ color: 'var(--fg-mute)', fontSize: 11, marginTop: 4 }}>{a.org}</div>
          <div style={{ color: 'var(--fg)', fontSize: 12, marginTop: 8, borderLeft: '2px solid var(--accent)', paddingLeft: 10 }}>
            {a.detail}
          </div>
        </Box>
      ))}
    </div>
  );
}

// ── Contact ────────────────────────────────────────────────────────────
function AppContact() {
  const d = D();
  const links = [
    { label: 'GitHub', url: d.links.github, cmd: 'open github', glyph: '<>' },
    { label: 'LinkedIn', url: d.links.linkedin, cmd: 'open linkedin', glyph: 'in' },
    { label: 'Email', url: d.links.email, cmd: 'mail ' + d.user.email, glyph: '@' },
    { label: 'Resume.pdf', url: d.links.resume, cmd: 'open resume', glyph: '📄' },
  ];
  return (
    <div style={appPad}>
      <div style={{ fontSize: 11, color: 'var(--fg-mute)', letterSpacing: '0.1em' }}>$ ./contact.sh --all</div>
      <TuiDivider />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 12 }}>
        {links.map((l) => (
          <a key={l.label} href={l.url} target="_blank" rel="noreferrer"
            style={{
              display: 'block',
              border: '1px solid var(--border-bright)',
              padding: 14,
              color: 'var(--fg)',
              textDecoration: 'none',
              background: 'var(--surface)',
              transition: 'all 0.15s',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = 'var(--accent)';
              e.currentTarget.style.background = 'var(--surface-alt)';
              e.currentTarget.style.boxShadow = '0 0 12px var(--accent-glow)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = 'var(--border-bright)';
              e.currentTarget.style.background = 'var(--surface)';
              e.currentTarget.style.boxShadow = 'none';
            }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{
                width: 36, height: 36,
                border: '1px solid var(--accent)',
                color: 'var(--accent)',
                textShadow: 'var(--text-glow)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontWeight: 700, fontSize: 14,
              }}>{l.glyph}</div>
              <div>
                <div style={{ color: 'var(--accent)', fontSize: 13, fontWeight: 700, textShadow: 'var(--text-glow)' }}>{l.label}</div>
                <div style={{ color: 'var(--fg-mute)', fontSize: 10, marginTop: 2 }}>$ {l.cmd}</div>
              </div>
            </div>
          </a>
        ))}
      </div>
      <TuiDivider label="DIRECT" />
      <div style={{ fontSize: 12, color: 'var(--fg-dim)' }}>
        <div><span style={{ color: 'var(--accent)' }}>email</span>  ─  {d.user.email}</div>
        <div><span style={{ color: 'var(--accent)' }}>phone</span>  ─  {d.user.phone}</div>
        <div><span style={{ color: 'var(--accent)' }}>loc&nbsp;&nbsp;</span>  ─  {d.user.location}</div>
      </div>
    </div>
  );
}

// ── Settings ───────────────────────────────────────────────────────────
function AppSettings({ flavor, mode, onFlavor, onMode }) {
  const flavors = [
    { key: 'phosphor', name: 'PHOSPHOR-9', note: 'green CRT · scanlines' },
    { key: 'amber', name: 'AMBER-7', note: 'amber phosphor · warm' },
    { key: 'neo', name: 'NEO-TERM', note: 'modern dark · cyan' },
  ];
  return (
    <div style={appPad}>
      <div style={{ fontSize: 11, color: 'var(--fg-mute)', letterSpacing: '0.1em' }}>$ settings --interactive</div>
      <TuiDivider label="DISPLAY FLAVOR" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 10 }}>
        {flavors.map((f) => (
          <button key={f.key} onClick={() => onFlavor(f.key)}
            style={{
              padding: 12,
              border: `1px solid ${flavor === f.key ? 'var(--accent)' : 'var(--border-bright)'}`,
              background: flavor === f.key ? 'var(--surface-alt)' : 'var(--surface)',
              color: flavor === f.key ? 'var(--accent)' : 'var(--fg-dim)',
              textShadow: flavor === f.key ? 'var(--text-glow)' : 'none',
              textAlign: 'left',
              fontFamily: 'var(--font-mono)',
              cursor: 'pointer',
              boxShadow: flavor === f.key ? '0 0 12px var(--accent-glow)' : 'none',
            }}>
            <div style={{ fontSize: 13, fontWeight: 700 }}>{flavor === f.key ? '◉' : '◌'} {f.name}</div>
            <div style={{ fontSize: 10, color: 'var(--fg-mute)', marginTop: 4 }}>{f.note}</div>
          </button>
        ))}
      </div>

      <TuiDivider label="COLOR MODE" />
      <div style={{ display: 'flex', gap: 10 }}>
        {[{ k: 'dark', g: '◐' }, { k: 'light', g: '◑' }].map((m) => (
          <button key={m.k} onClick={() => onMode(m.k)}
            style={{
              padding: '10px 18px',
              border: `1px solid ${mode === m.k ? 'var(--accent)' : 'var(--border-bright)'}`,
              background: mode === m.k ? 'var(--surface-alt)' : 'var(--surface)',
              color: mode === m.k ? 'var(--accent)' : 'var(--fg-dim)',
              textShadow: mode === m.k ? 'var(--text-glow)' : 'none',
              fontFamily: 'var(--font-mono)',
              cursor: 'pointer',
              flex: 1,
              fontSize: 12,
              letterSpacing: '0.08em',
            }}>
            {m.g} {m.k.toUpperCase()}
          </button>
        ))}
      </div>

      <TuiDivider label="SYSTEM INFO" />
      <div style={{ fontSize: 12, color: 'var(--fg-dim)', lineHeight: 1.8 }}>
        <div><span style={{ color: 'var(--accent)' }}>os</span>     ─ VishalRavi's Portfolio OS</div>
        <div><span style={{ color: 'var(--accent)' }}>kernel</span> ─ react.18.3.1-tui</div>
        <div><span style={{ color: 'var(--accent)' }}>shell</span>  ─ /bin/portfolio-sh</div>
        <div><span style={{ color: 'var(--accent)' }}>uptime</span> ─ <Uptime /></div>
      </div>
    </div>
  );
}

function Uptime() {
  const [start] = React.useState(() => Date.now());
  const [now, setNow] = React.useState(Date.now());
  React.useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const s = Math.floor((now - start) / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  return <span>{h}h {m % 60}m {s % 60}s</span>;
}

// ── Resume viewer ──────────────────────────────────────────────────────
function AppResume() {
  const d = D();
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg-inset)' }}>
      <div style={{ padding: '8px 12px', borderBottom: '1px solid var(--border-bright)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
        <div style={{ fontSize: 11, color: 'var(--fg-mute)', letterSpacing: '0.08em', fontFamily: 'var(--font-mono)' }}>
          📄 Vishal_Ravi_Muthaiah_Resume.pdf
        </div>
        <a href={d.links.resume} target="_blank" rel="noreferrer"
          style={{
            fontSize: 11, color: 'var(--accent)', textShadow: 'var(--text-glow)',
            border: '1px solid var(--accent)', padding: '3px 10px',
            textDecoration: 'none', fontFamily: 'var(--font-mono)', letterSpacing: '0.06em',
          }}>↗ OPEN IN NEW TAB</a>
      </div>
      <iframe src={d.links.resume} title="Resume" style={{ flex: 1, width: '100%', border: 0, background: '#fff' }} />
    </div>
  );
}

// ── Help ───────────────────────────────────────────────────────────────
function AppHelp() {
  const cmds = [
    ['help', 'show this list'],
    ['ls / dir', 'list available apps'],
    ['open <app>', 'launch an app window'],
    ['about', 'print bio'],
    ['projects [n]', 'list projects or open #n'],
    ['experience', 'work history'],
    ['education', 'degrees'],
    ['skills', 'tech stack'],
    ['awards', 'publications & awards'],
    ['contact', 'show contact info'],
    ['cat resume.txt', 'plain-text resume'],
    ['whoami', 'current user'],
    ['date', 'current datetime'],
    ['theme <flavor>', 'phosphor | amber | neo'],
    ['mode <dark|light>', 'switch color mode'],
    ['neofetch', 'system summary'],
    ['clear', 'clear the screen'],
    ['exit / close', 'close terminal'],
  ];
  return (
    <div style={appPad}>
      <div style={{ fontSize: 11, color: 'var(--fg-mute)', letterSpacing: '0.1em' }}>$ man portfolio-sh</div>
      <TuiDivider label="COMMANDS" />
      <table style={{ width: '100%', fontSize: 12, borderCollapse: 'collapse' }}>
        <tbody>
          {cmds.map(([c, d]) => (
            <tr key={c}>
              <td style={{ padding: '4px 12px 4px 0', color: 'var(--accent)', textShadow: 'var(--text-glow)', whiteSpace: 'nowrap', verticalAlign: 'top' }}>
                {c}
              </td>
              <td style={{ padding: '4px 0', color: 'var(--fg-dim)' }}>{d}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

window.OS_APPS = {
  about: AppAbout,
  projects: AppProjects,
  experience: AppExperience,
  education: AppEducation,
  skills: AppSkills,
  achievements: AppAchievements,
  contact: AppContact,
  settings: AppSettings,
  resume: AppResume,
  help: AppHelp,
};
